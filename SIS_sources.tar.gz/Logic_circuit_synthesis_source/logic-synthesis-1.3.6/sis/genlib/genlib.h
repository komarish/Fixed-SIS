/*
 * Revision Control Information
 *
 * $Source: /users/pchong/CVS/sis/sis/genlib/genlib.h,v $
 * $Author: pchong $
 * $Revision: 1.1.1.1 $
 * $Date: 2004/02/07 10:14:30 $
 *
 */
/* file @(#)genlib.h	1.1                      */
/* last modified on 5/29/91 at 12:35:24   */
/* exported functions to mis ... */

extern int genlib_parse_library();
